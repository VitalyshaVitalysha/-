# DNSCryptClient
Qt/KF5 GUI wrapper over dnscrypt-proxy (v.1 & v.2)

Contains systemd instantiated unit for control proxying service.
Works with local (127.0.0.1 by default) address and service list from
dnscrypt-proxy package.
Implemented restore DNS resolver system settings.
